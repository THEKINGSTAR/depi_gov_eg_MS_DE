USE CompanyDB
GO

CREATE PROCEDURE PerformQueryTasks
AS
BEGIN
    -- Number of Employees of Each Department
    SELECT Departments.DepartmentName AS [Department Name], COUNT(EmployeeID) AS number_of_employees
    FROM dbo.Employees AS Employees 
    INNER JOIN dbo.Departments AS Departments 
        ON Employees.DepartmentID = Departments.DepartmentID
    GROUP BY Departments.DepartmentID, Departments.DepartmentName


    -- Assignments for each employee
    SELECT CONCAT(Employees.FirstName, ' ' + Employees.LastName) AS [Full Name],
            Assignments.Role AS Role,
            Projects.ProjectName AS [Project Name],
            Assignments.AssignmentID
    FROM dbo.Assignments AS Assignments
    INNER JOIN dbo.Employees AS Employees
        ON Assignments.EmployeeID = Employees.EmployeeID
    INNER JOIN dbo.Projects AS Projects
        ON Assignments.ProjectID = Projects.ProjectID
    ORDER BY Assignments.ProjectID

    --     the budget column is null
    --     Find the cost of all projects
    --     SELECT SUM(pro.Budget) AS All_Projects_Cost
    --     FROM Projects pro

   -- Find all employees ids, names and position within a specific department
        SELECT emp.EmployeeID, emp.FirstName + ' ' + emp.LastName AS NAME, emp .Position 
        FROM Employees emp
        JOIN Departments  dep
            ON dep.DepartmentID = emp.DepartmentID  
        WHERE DepartmentName = ''

    -- Find all projects that will take more than a month
        SELECT pro.ProjectID, pro.ProjectName , DATEDIFF(MONTH,EndDate,StartDate) AS Duration
        FROM Projects pro
        WHERE DATEDIFF(MONTH,EndDate,StartDate) > 1
    
    --Projects That Have Not Been Assigned to Any Employees
    SELECT p.ProjectID, p.ProjectName
    FROM Projects p
    LEFT JOIN Assignments a ON p.ProjectID = a.ProjectID
    WHERE a.AssignmentID IS NULL;    

    -- Average Salary for each Department
    SELECT d.DepartmentName, AVG(e.Salary) AS AverageSalary
    FROM Departments d
    JOIN Employees e ON d.DepartmentID = e.DepartmentID
    GROUP BY d.DepartmentName;

    --THE QUERY WILL OUTPUT NULL BECAUSE THE SALARY COLUMN IS EMPTY
        

    
    --CTE For Employee Details
    WITH EmployeeDetails AS (
        SELECT 
            e.EmployeeID,
            e.FirstName,
            e.LastName,
            d.DepartmentName
        FROM 
            Employees e
        JOIN 
            Departments d ON e.DepartmentID = d.DepartmentID
    )

    SELECT *
    FROM EmployeeDetails

END