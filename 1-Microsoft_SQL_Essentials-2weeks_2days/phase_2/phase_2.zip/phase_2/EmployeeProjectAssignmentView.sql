CREATE VIEW EmployeeProjectAssignments
AS
    SELECT emp.FirstName + ' ' + emp.LastName AS Name, 
            dep.DepartmentName, 
            pro.ProjectName, 
            assi.Role, 
            DATEDIFF(day,pro.EndDate , pro.StartDate)  AS AssignmentDuration
    FROM Employees emp
    JOIN Departments dep
        ON dep.DepartmentID = emp.DepartmentID
    JOIN Assignments assi
        ON assi.EmployeeID = emp.EmployeeID
    JOIN Projects pro
        ON pro.ProjectID = assi.ProjectID;

select * 
from EmployeeProjectAssignments