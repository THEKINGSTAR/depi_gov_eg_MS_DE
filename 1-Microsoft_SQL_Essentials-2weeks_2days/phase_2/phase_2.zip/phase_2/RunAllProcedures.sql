
USE CompanyDB;
GO

CREATE PROCEDURE RunAllSetupProcedures
AS
PRINT 'Process Started';
BEGIN
    EXEC CreateTables;
    EXEC CreateConstraintsAndRelationships;
    EXEC InsertDataFromAnotherDataBase
    EXEC PerformQueryTasks
    EXEC CreateViews
	
END




