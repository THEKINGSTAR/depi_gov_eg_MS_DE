
USE CompanyDB;
GO

    EXEC CreateTables;
    EXEC CreateConstraintsAndRelationships;
    EXEC InsertDataFromAnotherDataBase
    EXEC PerformQueryTasks
    EXEC CreateViews

GO

