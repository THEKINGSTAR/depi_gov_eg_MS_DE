USE CompanyDB;
GO

CREATE PROCEDURE InsertDataFromAnotherDataBase
AS
BEGIN

    INSERT INTO Departments
    SELECT *
    FROM SourceDB.dbo.Departments
    
    INSERT INTO Employees(EmployeeID,FirstName,LastName,DepartmentID,HireDate)
    SELECT *
    FROM SourceDB.dbo.Employees

    INSERT INTO Projects (ProjectID,ProjectName,StartDate,EndDate)
    SELECT *
    FROM SourceDB.dbo.Projects

    -- DELETE FROM Assignments
    INSERT INTO CompanyDB.dbo.Assignments (AssignmentID, EmployeeID,ProjectID,Role,AssignmentDate)
    SELECT AssignmentID, EmployeeID, ProjectID, Role, StartDate
    FROM SourceDB.dbo.Assignments

END