IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'CreateTables')
BEGIN
    DROP PROCEDURE CreateTables;
	PRINT 'Dropped existing procedure CreateTables.';

END;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'CompanyDB')
BEGIN
    DROP DATABASE CompanyDB;
END;
GO

CREATE DATABASE CompanyDB;
GO
USE CompanyDB
GO

CREATE PROCEDURE CreateTables
AS
PRINT 'Created Tables';
BEGIN
	CREATE TABLE Departments (
		DepartmentID INT PRIMARY KEY,
		DepartmentName VARCHAR(100) NOT NULL,
		Locations VARCHAR(100)
	);
	CREATE TABLE Employees (
		EmployeeID INT PRIMARY KEY,
		FirstName VARCHAR(50) NOT NULL,
		LastName VARCHAR(50) NOT NULL,
		DepartmentID INT NOT NULL,
		HireDate DATE NOT NULL,
		Position VARCHAR(100),
		Salary DECIMAL(10, 2) CHECK (Salary > 0)
	);
	CREATE TABLE Projects (
		ProjectID INT PRIMARY KEY,
		ProjectName VARCHAR(100) NOT NULL,
		StartDate DATE NOT NULL,
		EndDate DATE,
		Budget DECIMAL(12, 2)
	);


	CREATE TABLE Assignments (
		AssignmentID INT PRIMARY KEY,
		EmployeeID INT,
		ProjectID INT,
		Role VARCHAR(100),
		AssignmentDate DATE
	);
	
END

