USE CompanyDB;

GO

CREATE PROCEDURE CreateConstraintsAndRelationships
AS
BEGIN
    ALTER TABLE Employees
    ADD CONSTRAINT FK_DEPARTMENTS
    FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID);

    ALTER TABLE Assignments
    ADD CONSTRAINT FK_PROJECT
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID);

    ALTER TABLE Assignments
    ADD CONSTRAINT FK_EMPLOYEE
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID);

	ALTER TABLE Employees
	ADD CONSTRAINT CHK_HIREDATE
	CHECK (HireDate <= GETDATE());
END;
GO

